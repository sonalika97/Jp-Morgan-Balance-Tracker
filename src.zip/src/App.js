import React, { useEffect, useState } from "react";

function App() {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchBalance = async () => {
    try {
      setLoading(true);
      const res = await fetch("http://localhost:8080/balance");
      const json = await res.json();
      setData(json);
      setError("");
    } catch (e) {
      setError("Error fetching balance");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBalance();
    const timer = setInterval(fetchBalance, 2000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div style={styles.page}>

      {/* NAVIGATION BAR */}
      <div style={styles.navbar}>
        <div style={styles.bankLogo}>
          <span style={styles.bankIcon}>🏛️</span>
          <span style={styles.bankName}>JP Morgan Chase Bank</span>
        </div>

        <div style={styles.menuItems}>
          <span style={styles.menuText}>Dashboard</span>
          <span style={styles.menuText}>Accounts</span>
          <span style={styles.menuText}>Services</span>
          <span style={styles.menuText}>User Profile</span>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div style={styles.wrapper}>
        <div style={styles.card}>
          <h1 style={styles.title}>Account Overview</h1>

          {/* ⭐ New Bank Account Header ⭐ */}
          <div style={styles.accountBox}>
            <p style={styles.accLine}><strong>Account Holder:</strong> Sonalika </p>
            <p style={styles.accLine}><strong>Account Number:</strong> 8239 44 1882</p>
            <p style={styles.accLine}><strong>Sort Code:</strong> 30-45-90</p>
            <p style={styles.accLine}><strong>Account Type:</strong> Current Account</p>
          </div>

          {loading && <p style={styles.info}>Loading...</p>}
          {error && <p style={styles.error}>{error}</p>}

          {/* Balance rows */}
          {data && (
            <div>
              <div style={styles.row}>
                <span style={styles.label}>Net Balance:</span>
                <span style={styles.green}>£ {data.netBalance.toFixed(2)}</span>
              </div>

              <div style={styles.row}>
                <span style={styles.label}>Total Credits:</span>
                <span style={styles.value}>£ {data.totalCredits.toFixed(2)}</span>
              </div>

              <div style={styles.row}>
                <span style={styles.label}>Total Debits:</span>
                <span style={styles.value}>£ {data.totalDebits.toFixed(2)}</span>
              </div>

              <div style={styles.row}>
                <span style={styles.label}>Transactions Processed:</span>
                <span style={styles.value}>{data.totalTransactionsProcessed}</span>
              </div>

              <div style={styles.row}>
                <span style={styles.label}>Last 1000 Stored:</span>
                <span style={styles.value}>{data.last1000Stored}</span>
              </div>
            </div>
          )}

          <button style={styles.btn} onClick={fetchBalance}>Refresh</button>
        </div>
      </div>

    </div>
  );
}

const styles = {
  page: {
    height: "100vh",
    background: "#0f172a",
    fontFamily: "Arial",
  },

  navbar: {
    height: "65px",
    width: "100%",
    background: "#1b263b",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "0 30px",
    boxShadow: "0 3px 10px rgba(0,0,0,0.4)",
    position: "fixed",
    top: 0,
    left: 0,
    zIndex: 100,
  },

  bankLogo: { display: "flex", alignItems: "center", gap: "12px" },
  bankIcon: { fontSize: "28px" },
  bankName: {
    fontSize: "20px",
    fontWeight: "bold",
    color: "#e2e8f0",
  },

  menuItems: { display: "flex", gap: "30px" },
  menuText: {
    color: "#cbd5e1",
    fontSize: "15px",
    cursor: "pointer",
  },

  wrapper: {
    marginTop: "120px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },

  card: {
    background: "#1e293b",
    padding: "30px",
    borderRadius: "12px",
    width: "420px",
    boxShadow: "0 4px 20px rgba(0,0,0,0.5)",
    color: "#e2e8f0",
  },

  title: {
    textAlign: "center",
    fontSize: "24px",
    marginBottom: "20px",
    color: "#f8fafc",
  },

  accountBox: {
    background: "#243447",
    padding: "15px",
    borderRadius: "10px",
    marginBottom: "20px",
    border: "1px solid #3b4b5b",
  },

  accLine: {
    margin: "4px 0",
    color: "#cbd5e1",
    fontSize: "14px",
  },

  row: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "10px",
  },

  label: { color: "#94a3b8" },
  value: { color: "#e2e8f0" },
  green: { color: "#4ade80", fontWeight: "bold" },

  btn: {
    width: "100%",
    padding: "10px",
    marginTop: "20px",
    background: "#3b82f6",
    borderRadius: "8px",
    color: "white",
    border: "none",
    fontWeight: "bold",
    cursor: "pointer",
  },

  error: { color: "#f87171" },
  info: { color: "#94a3b8" },
};

export default App;
